const APP_NAME = 'FISABytes';
document.getElementById('app-title').textContent = APP_NAME; 